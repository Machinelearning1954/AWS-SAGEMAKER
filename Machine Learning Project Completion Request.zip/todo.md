# Capstone Project Todo List

## Phase 1: Building a Working Prototype

- [X] **Step 1: Review Project Document and Requirements:** Thoroughly understand the capstone project rubric, learning objectives, and all submission requirements for both phases.
- [X] **Step 2: Define Problem Statement and Objectives:**
    - [X] Brainstorm and select a project idea with practical application and justifiable value.
    - [X] Clearly define the problem the project aims to solve.
    - [X] Outline specific, measurable, achievable, relevant, and time-bound (SMART) objectives.
    - [X] Describe potential outcomes and how they can be used.
    - [X] Ensure the project is scoped appropriately for the course.
- [X] **Step 3: Data Collection:**
    - [X] Identify and select well-chosen and relevant datasets (e.g., from public city data, public APIs, Google dataset search, AWS open datasets, Uber Movement, or other sources like Kaggle, UCI ML Repository).
    - [X] Document the data acquisition process.
- [ ] **Step 4: Project Proposal:**
    - [ ] Write a detailed project proposal covering the problem, objectives, data sources, proposed methodology, and evaluation plan.
- [ ] **Step 5: Survey Existing Research:**
    - [ ] Conduct a literature review of existing research and similar projects related to the chosen problem.
    - [ ] Summarize findings and how they inform the project approach.
- [X] **Step 6: Data Wrangling and Preprocessing (Implement Data Pipeline):**
    - [X] Clean the collected data (handle missing values, outliers, inconsistencies).
    - [X] Perform exploratory data analysis (EDA) to understand data characteristics.
    - [X] Implement feature engineering and selection techniques.
    - [X] Create a robust data pipeline for preprocessing.
- [X] **Step 7: Design and Select Appropriate Machine Learning Models:**
    - [X] Based on the problem and data, select and justify appropriate machine learning/deep learning algorithms and applications.
    - [X] Define evaluation metrics and techniques suitable for the problem.
- [X] **Step 8: Train and Evaluate Models (on AWS Sagemaker):**
    - [X] Implement the selected models.
    - [X] Train the models using the preprocessed data, preferably utilizing AWS Sagemaker.
    - [X] Evaluate model performance using the defined metrics.
- [X] **Step 9: Analyze Results and Perform Hyperparameter Tuning (Benchmark Your Model - Optional but Recommended):**
    - [X] Analyze model results and identify areas for improvement.
    - [X] Perform hyperparameter tuning to optimize model performance.
    - [X] (Optional) Benchmark the model against existing solutions or baseline models.
- [X] **Step 10: Code and GitHub Repository:**
    - [X] Write clear, understandable, and well-documented code.
    - [X] Organize the project in a single GitHub repository.
    - [X] Create a clear and comprehensive README.md file.
    - [X] Ensure all intermediate capstone project submissions (Steps 1-6 from rubric) are included or referenced.

## Phase 2: Deploy to Production

- [ ] **Step 11: Design Deployment Architecture:**
    - [ ] Design a clear and well-justified deployment architecture appropriate for the problem, data, and model (e.g., using AWS Sagemaker endpoints, AWS Lambda, Elastic Beanstalk, or other suitable cloud services).
- [ ] **Step 12: Implement Deployment and User Interface:**
    - [ ] Deploy the trained model as a running application.
    - [ ] Develop a simple and intuitive user interface (UI) that allows users to interact with the model (e.g., a web application using Flask/Django, or a Streamlit/Gradio app).
- [ ] **Step 13: Testing:**
    - [ ] Thoroughly test the deployed application for functionality, performance, and robustness.
- [ ] **Step 14: Final GitHub Submission (Phase 2):**
    - [ ] Ensure all components from Phase 1 are included.
    - [ ] Add the deployed application code and UI components to the GitHub repository.
    - [ ] Update documentation, including deployment instructions and UI usage.

## Final Project Compilation and Submission

- [ ] **Step 15: Compile Final Report and Documentation:**
    - [ ] Create a comprehensive final report detailing the entire project: problem statement, data, methodology, experiments, results, deployment, and conclusions.
    - [ ] Ensure all documentation is complete and meets rubric requirements.
- [ ] **Step 16: Validate Completeness and Quality of Submission:**
    - [ ] Review the entire project against the capstone rubric to ensure all criteria are met.
    - [ ] Perform a final quality check of all deliverables (code, repository, report, deployed application).
- [ ] **Step 17: Report and Send Final Project to User:**
    - [ ] Prepare a summary of the completed project.
    - [ ] Provide the user with all deliverables, including the GitHub repository link and access to the deployed application.
