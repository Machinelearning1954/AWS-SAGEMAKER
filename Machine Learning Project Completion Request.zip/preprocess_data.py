import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# Define column names 
column_names = ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"] + \
               [f"sensor_{i}" for i in range(1, 22)]

# Load the first training dataset
data_path = "/home/ubuntu/turbofan_data/CMAPSSData/train_FD001.txt"
df_train_fd001 = pd.read_csv(data_path, sep="\s+", header=None, names=column_names, engine="python")

print("--- Original DataFrame shape ---")
print(df_train_fd001.shape)

# 1. Remove constant columns identified in EDA
constant_columns_to_drop = ["op_setting_3", "sensor_1", "sensor_5", "sensor_10", "sensor_16", "sensor_18", "sensor_19"]
df_train_fd001_cleaned = df_train_fd001.drop(columns=constant_columns_to_drop)
print("\n--- DataFrame shape after dropping constant columns ---")
print(df_train_fd001_cleaned.shape)
print("Remaining columns:", df_train_fd001_cleaned.columns.tolist())

# 2. Calculate Remaining Useful Life (RUL) for training data
# RUL is the number of cycles remaining before failure for each engine.
# First, get the maximum cycle for each unit (which is its total life)
max_cycles = df_train_fd001_cleaned.groupby("unit_number")["time_in_cycles"].max().reset_index()
max_cycles.columns = ["unit_number", "max_cycle_unit"]
# Merge this back to the original dataframe
df_train_fd001_cleaned = pd.merge(df_train_fd001_cleaned, max_cycles, on="unit_number", how="left")
# Calculate RUL
df_train_fd001_cleaned["RUL"] = df_train_fd001_cleaned["max_cycle_unit"] - df_train_fd001_cleaned["time_in_cycles"]
df_train_fd001_cleaned = df_train_fd001_cleaned.drop(columns=["max_cycle_unit"]) # Drop the intermediate column
print("\n--- DataFrame with RUL (first 5 rows of unit 1) ---")
print(df_train_fd001_cleaned[df_train_fd001_cleaned["unit_number"] == 1].head())
print("\n--- DataFrame with RUL (last 5 rows of unit 1) ---")
print(df_train_fd001_cleaned[df_train_fd001_cleaned["unit_number"] == 1].tail())

# 3. Apply Min-Max Normalization
# Features to normalize are operational settings and sensor measurements
# Exclude unit_number, time_in_cycles, and RUL from normalization for now.
# time_in_cycles might be normalized if used as a feature directly in some models, but often it's used to structure sequences.
features_to_normalize = [col for col in df_train_fd001_cleaned.columns if col not in ["unit_number", "time_in_cycles", "RUL"]]

scaler = MinMaxScaler()
df_train_fd001_cleaned[features_to_normalize] = scaler.fit_transform(df_train_fd001_cleaned[features_to_normalize])
print("\n--- DataFrame after Min-Max Normalization (first 5 rows) ---")
print(df_train_fd001_cleaned.head())

# Save the scaler for later use on the test set
import joblib
joblib.dump(scaler, "/home/ubuntu/min_max_scaler_fd001.save")
print("\nScaler saved to /home/ubuntu/min_max_scaler_fd001.save")

# 4. Prepare sequences for time-series models
sequence_length = 50 # Hyperparameter: length of the input sequence

def create_sequences(df, sequence_length, feature_cols, target_col):
    sequences = []
    targets = []
    num_units = df["unit_number"].nunique()
    for unit_id in range(1, num_units + 1):
        unit_data = df[df["unit_number"] == unit_id]
        # Ensure we have enough data for at least one sequence
        if len(unit_data) < sequence_length:
            continue
        # Create sequences for this unit
        for i in range(len(unit_data) - sequence_length + 1):
            seq = unit_data[feature_cols].iloc[i:i+sequence_length].values
            target = unit_data[target_col].iloc[i+sequence_length-1] # RUL at the end of the sequence
            sequences.append(seq)
            targets.append(target)
    return np.array(sequences), np.array(targets)

# Define feature columns for sequences (normalized op_settings and sensors)
sequence_feature_columns = features_to_normalize # These are already normalized

X_train_sequences, y_train_rul = create_sequences(df_train_fd001_cleaned, 
                                                  sequence_length, 
                                                  sequence_feature_columns, 
                                                  "RUL")

print(f"\n--- Shape of X_train_sequences: {X_train_sequences.shape} ---") # (num_sequences, sequence_length, num_features)
print(f"--- Shape of y_train_rul: {y_train_rul.shape} ---") # (num_sequences,)
print("Example of first sequence and its target RUL:")
if len(X_train_sequences) > 0:
    print(X_train_sequences[0])
    print(y_train_rul[0])

# Save processed data
np.save("/home/ubuntu/X_train_fd001_sequences.npy", X_train_sequences)
np.save("/home/ubuntu/y_train_fd001_rul.npy", y_train_rul)
print("\nProcessed sequences and RUL targets saved.")

print("\nPreprocessing script completed.")


