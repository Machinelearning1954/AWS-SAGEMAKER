# Predictive Maintenance for Turbofan Engines

## Project Overview
This project focuses on developing a predictive maintenance model for turbofan engines using the NASA C-MAPSS dataset. The goal is to predict the Remaining Useful Life (RUL) of these engines, enabling proactive maintenance and reducing operational disruptions.

## Repository Structure

- `data/`: Contains the raw and processed datasets (Note: Due to size, raw data might need tobe downloaded separately from the provided NASA repository link).
  - `CMAPSSData/`: Subdirectory for the raw CMAPSS dataset files (e.g., `train_FD001.txt`, `test_FD001.txt`, `RUL_FD001.txt`).
  - `processed_data/`: Directory for storing preprocessed data files (e.g., `X_train_fd001_sequences.npy`, `y_train_fd001_rul.npy`).
- `notebooks/`: Jupyter notebooks for data exploration, preprocessing, and model development.
  - `01_Data_Exploration.ipynb`: Notebook for initial data loading, visualization, and understanding.
  - `02_Data_Preprocessing.ipynb`: Notebook detailing the steps for cleaning, transforming, and preparing the data for modeling.
  - `03_Model_Training_and_Evaluation.ipynb`: Notebook for building, training, and evaluating the LSTM model.
  - `04_Hyperparameter_Tuning.ipynb`: Notebook for hyperparameter optimization using Keras Tuner.
- `src/`: Contains Python scripts for various tasks.
  - `data_loader.py`: Script for loading and handling the dataset.
  - `preprocessing.py`: Script for data cleaning and feature engineering.
  - `model.py`: Script defining the LSTM model architecture.
  - `train.py`: Script for training the model.
  - `evaluate.py`: Script for evaluating the model performance.
  - `tune.py`: Script for hyperparameter tuning (this is the `hyperparameter_tuning.py` script).
- `model_artifacts/`: Directory to store trained models and performance plots.
  - `lstm_rul_predictor_fd001.keras`: Saved Keras model from initial training.
  - `training_validation_loss_fd001.png`: Plot of training and validation loss from initial training.
  - `training_validation_rmse_fd001.png`: Plot of training and validation RMSE from initial training.
  - `tuning/`: Subdirectory for hyperparameter tuning results.
    - `best_lstm_model_fd001.keras`: Best model found during hyperparameter tuning.
    - `best_model_loss_fd001.png`: Plot of training and validation loss for the best model.
    - `best_model_rmse_fd001.png`: Plot of training and validation RMSE for the best model.
- `reports/`: Contains the final project report and any other documentation.
  - `Final_Project_Report.md`: The main report detailing the project, methodology, results, and conclusions (this is the `model_analysis.md` file, renamed for clarity).
  - `Data_Pipeline_and_Preprocessing.md`: Detailed documentation of the data processing steps.
  - `Model_Selection_and_Architecture.md`: Explanation of the model choice and its architecture.
- `README.md`: This file, providing an overview of the project and instructions.
- `requirements.txt`: Lists the Python dependencies required to run the project.

## Setup and Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd <repository_name>
    ```
2.  **Create a virtual environment (recommended):**
    ```bash
    python3 -m venv venv
    source venv/bin/activate  # On Windows use `venv\Scripts\activate`
    ```
3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
4.  **Download the dataset:**
    Download the C-MAPSS dataset from the NASA Prognostics Data Repository and place the `train_FD001.txt`, `test_FD001.txt`, and `RUL_FD001.txt` files into the `data/CMAPSSData/` directory.

## Usage

1.  **Data Preprocessing:**
    Run the preprocessing script to prepare the data:
    ```bash
    python src/preprocess_data.py
    ```
    This will generate the `X_train_fd001_sequences.npy` and `y_train_fd001_rul.npy` files in the `data/processed_data/` directory, and the scaler object in `model_artifacts/`.

2.  **Model Training:**
    To train the LSTM model with the best hyperparameters found:
    ```bash
    python src/train_evaluate_lstm.py 
    ```
    This script will load the preprocessed data, build the LSTM model with the optimal hyperparameters, train it, and save the trained model and performance plots in the `model_artifacts/tuning/` directory.

3.  **Hyperparameter Tuning (Optional):**
    To run the hyperparameter tuning process (this can be time-consuming):
    ```bash
    python src/hyperparameter_tuning.py
    ```
    This will perform a Hyperband search and save the results in the `keras_tuner_dir` directory, as well as the best model and its training plots in `model_artifacts/tuning/`.

## Results

The primary evaluation metric is the Root Mean Squared Error (RMSE) on the test set. The model achieved an RMSE of approximately 20.04 on the validation set after hyperparameter tuning. Detailed results, including loss and RMSE curves, are available in the `reports/Final_Project_Report.md` and the `model_artifacts/tuning/` directory.

## Conclusion

This project demonstrates the successful application of LSTM neural networks for predicting the Remaining Useful Life (RUL) of turbofan engines. The model, after preprocessing and hyperparameter tuning, shows promising results. Further work could involve exploring more complex architectures, additional feature engineering, and deployment for real-time monitoring.

## Contributing

(This section would typically include guidelines for contributing to the project if it were an open-source project. For this academic project, it might be omitted or adapted.)

## License

(Specify the license under which the project is released, e.g., MIT, Apache 2.0, etc. If not applicable for an academic project, this can be omitted.)

