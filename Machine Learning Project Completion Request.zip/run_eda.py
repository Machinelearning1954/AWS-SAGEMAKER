import pandas as pd
import numpy as np

# Define column names based on readme.txt
column_names = ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"] + \
               [f"sensor_measurement_{i}" for i in range(1, 22)] + \
               ["sensor_measurement_22", "sensor_measurement_23"] # Placeholder for sensor 22, 23 if they exist based on 26 columns mentioned

# Correcting column names based on the readme (21 sensors, so 26 columns total)
# 1 unit_number, 1 time_in_cycles, 3 op_settings, 21 sensor_measurements = 26 columns
# The readme says "sensor measurement 1 ... sensor measurement 26" which is confusing.
# Let's re-verify. "26 columns of numbers... 1) unit number ... 5) op setting 3 ... 6) sensor measurement 1 ... 26) sensor measurement 21"
# This means columns 6 through 26 are sensor measurements 1 through 21.
column_names_corrected = ["unit_number", "time_in_cycles", "op_setting_1", "op_setting_2", "op_setting_3"] + \
                         [f"sensor_{i}" for i in range(1, 22)]

# Load the first training dataset
data_path = "/home/ubuntu/turbofan_data/CMAPSSData/train_FD001.txt"

try:
    df_train_fd001 = pd.read_csv(data_path, sep="\s+", header=None, names=column_names_corrected, engine="python")

    print("--- First 5 rows of train_FD001.txt ---")
    print(df_train_fd001.head())
    print("\n--- DataFrame Info ---")
    df_train_fd001.info()
    print("\n--- Descriptive Statistics ---")
    print(df_train_fd001.describe().transpose())
    print("\n--- Missing Values Check ---")
    print(df_train_fd001.isnull().sum())

    # Check for constant columns (sensors that don't change value)
    constant_columns = df_train_fd001.columns[df_train_fd001.nunique() == 1]
    print("\n--- Constant Value Columns ---")
    if not constant_columns.empty:
        print(constant_columns.tolist())
        for col in constant_columns:
            print(f"{col}: {df_train_fd001[col].unique()}")
    else:
        print("No constant value columns found.")

    # Save the output to a file for documentation
    # Create a buffer to capture df.info() output
    import io
    buffer = io.StringIO()
    df_train_fd001.info(buf=buffer)
    info_str = buffer.getvalue()

    output_eda_summary = f"""
--- First 5 rows of train_FD001.txt ---
{df_train_fd001.head().to_string()}

--- DataFrame Info ---
{info_str}
--- Descriptive Statistics ---
{df_train_fd001.describe().transpose().to_string()}

--- Missing Values Check ---
{df_train_fd001.isnull().sum().to_string()}

--- Constant Value Columns ---
""" # Corrected closing triple quote position
    if not constant_columns.empty:
        output_eda_summary += f"{constant_columns.tolist()}\n"
        for col in constant_columns:
            output_eda_summary += f"{col}: {df_train_fd001[col].unique()}\n"
    else:
        output_eda_summary += "No constant value columns found.\n"

    with open("/home/ubuntu/eda_summary_fd001.txt", "w") as f:
        f.write(output_eda_summary)
    print("\nEDA summary saved to /home/ubuntu/eda_summary_fd001.txt")

except Exception as e:
    print(f"Error during EDA: {e}")


