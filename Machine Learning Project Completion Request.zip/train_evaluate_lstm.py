import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import matplotlib.pyplot as plt
import os

# Create a directory for saving models and plots if it doesn't exist
if not os.path.exists("/home/ubuntu/model_artifacts"):
    os.makedirs("/home/ubuntu/model_artifacts")

# Load preprocessed data
print("Loading preprocessed training data...")
X_train = np.load("/home/ubuntu/X_train_fd001_sequences.npy")
y_train = np.load("/home/ubuntu/y_train_fd001_rul.npy")

print(f"Shape of X_train: {X_train.shape}")
print(f"Shape of y_train: {y_train.shape}")

if X_train.shape[0] == 0:
    print("Error: No training sequences loaded. Exiting.")
    exit()

# Model Architecture
print("Defining LSTM model architecture...")
model = Sequential()
# Input shape: (sequence_length, num_features)
# X_train.shape[1] is sequence_length, X_train.shape[2] is num_features
model.add(LSTM(units=100, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])))
model.add(Dropout(0.2))
model.add(LSTM(units=50, return_sequences=False))
model.add(Dropout(0.2))
model.add(Dense(units=1)) # Output layer for RUL prediction (regression)

# Compile the model
print("Compiling the model...")
model.compile(optimizer='adam', loss='mean_squared_error', metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse')])
model.summary()

# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
model_checkpoint = ModelCheckpoint("/home/ubuntu/model_artifacts/lstm_rul_predictor_fd001.keras", monitor='val_loss', save_best_only=True)

# Train the model
print("Training the model...")
# Splitting a small portion of training data for validation during training
history = model.fit(X_train, y_train, epochs=50, batch_size=64, validation_split=0.2, 
                    callbacks=[early_stopping, model_checkpoint], verbose=1)

print("Model training completed.")

# Save the final model (even if checkpoint saved the best one, this saves the last state after early stopping)
model.save("/home/ubuntu/model_artifacts/lstm_rul_predictor_fd001_final.keras")
print("Final trained model saved to /home/ubuntu/model_artifacts/lstm_rul_predictor_fd001_final.keras")

# Plot training history
print("Plotting training history...")
plt.figure(figsize=(12, 6))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss Over Epochs')
plt.ylabel('Mean Squared Error (Loss)')
plt.xlabel('Epoch')
plt.legend()
plt.savefig("/home/ubuntu/model_artifacts/training_validation_loss_fd001.png")
print("Training history plot saved to /home/ubuntu/model_artifacts/training_validation_loss_fd001.png")

plt.figure(figsize=(12, 6))
plt.plot(history.history['rmse'], label='Training RMSE')
plt.plot(history.history['val_rmse'], label='Validation RMSE')
plt.title('Model RMSE Over Epochs')
plt.ylabel('Root Mean Squared Error')
plt.xlabel('Epoch')
plt.legend()
plt.savefig("/home/ubuntu/model_artifacts/training_validation_rmse_fd001.png")
print("Training RMSE plot saved to /home/ubuntu/model_artifacts/training_validation_rmse_fd001.png")

print("Script finished.")


