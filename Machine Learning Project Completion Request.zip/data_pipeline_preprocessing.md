# Capstone Project: Predictive Maintenance for Industrial Equipment

## 4. Data Pipeline and Preprocessing

### 4.1. Data Acquisition and Understanding

The foundation of any successful machine learning project lies in the quality and relevance of the data used. For this predictive maintenance capstone project, the **NASA Turbofan Engine Degradation Simulation Data Set** has been selected. This dataset is widely recognized and utilized in the prognostics and health management (PHM) community, making it an excellent choice for developing and evaluating predictive maintenance models.

**Data Source and Acquisition:**

The dataset was acquired directly from the NASA Prognostics Center of Excellence (PCoE) Data Set Repository. Specifically, it was downloaded from the following official URL: [https://phm-datasets.s3.amazonaws.com/NASA/6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip](https://phm-datasets.s3.amazonaws.com/NASA/6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip).

The downloaded archive (`6. Turbofan Engine Degradation Simulation Data Set.zip`) contained a nested ZIP file (`CMAPSSData.zip`) and a PDF document (`Damage Propagation Modeling.pdf`) providing background on the simulation. The `CMAPSSData.zip` file was subsequently extracted to reveal the core data files.

**Dataset Structure and Contents:**

The extracted dataset consists of several text files, primarily divided into training sets, test sets, and corresponding Remaining Useful Life (RUL) values for the test sets. Additionally, a `readme.txt` file provides essential information about the data format and the meaning of different columns.

The dataset is divided into four sub-datasets (FD001, FD002, FD003, FD004), each corresponding to different operational conditions and fault modes:

*   **`train_FD00x.txt`**: These files contain the multivariate time-series data for the training units (engines). Each row represents a single operational cycle for a specific engine unit. The data includes:
    *   Unit number (engine ID)
    *   Time, in cycles
    *   Three operational settings
    *   21 sensor measurements (e.g., temperature, pressure, fan speed, etc.)
    The engines in the training set are run until failure.

*   **`test_FD00x.txt`**: These files contain the time-series data for the test units. The structure is similar to the training data, but the data for each engine ends some time prior to system failure. The task is to predict the RUL for these test units.

*   **`RUL_FD00x.txt`**: These files provide the true RUL values for each engine in the corresponding `test_FD00x.txt` data. This is the ground truth that will be used to evaluate the performance of the RUL prediction models.

*   **`readme.txt`**: This file describes the dataset, including the names of the columns (operational settings and sensor measurements), and provides context on the simulation.

*   **`Damage Propagation Modeling.pdf`**: This document offers a more in-depth explanation of the C-MAPSS (Commercial Modular Aero-Propulsion System Simulation) tool used to generate the synthetic data, detailing the engine model and the fault injection mechanisms.

The availability of multiple sub-datasets with varying complexities (e.g., FD001 has one fault mode and one operational condition, while FD004 has two fault modes and six operational conditions) allows for a comprehensive evaluation of the developed models under different scenarios.

This dataset is well-suited for the project's objective of predicting RUL or classifying failure likelihood, as it provides rich, multivariate time-series data capturing the degradation process of complex machinery. The next steps will involve a detailed exploratory data analysis (EDA) of this data to understand its characteristics, followed by preprocessing and feature engineering to prepare it for model training.



### 4.2. Exploratory Data Analysis (EDA) and Initial Preprocessing Insights

Following the acquisition and initial understanding of the NASA Turbofan Engine Degradation Simulation Data Set, a detailed Exploratory Data Analysis (EDA) was performed on the `train_FD001.txt` subset to gain deeper insights into its characteristics. This process is crucial for informing subsequent preprocessing steps such as data cleaning, feature engineering, and normalization.

The EDA involved loading the data into a pandas DataFrame, assigning appropriate column names based on the `readme.txt` file (unit number, time in cycles, 3 operational settings, and 21 sensor measurements). The primary findings from this initial EDA are summarized below:

**Data Structure and Integrity:**
The `train_FD001.txt` dataset comprises 20,631 records and 26 columns, consistent with the documentation. Each record represents an operational cycle for one of the 100 engine units in this subset. The data types were primarily float64 for sensor readings and operational settings, with integer types for unit number, time in cycles, and a few specific sensors (sensor_17, sensor_18), which is appropriate for numerical analysis.

**Missing Values:**
A key aspect of the EDA was to check for missing data. The analysis confirmed that there are **no missing values** in any of the columns in the `train_FD001.txt` dataset. This simplifies the preprocessing pipeline as imputation techniques for missing data are not immediately required for this subset. However, this will be re-verified for other subsets (FD002, FD003, FD004) as they are processed.

**Descriptive Statistics and Data Distribution:**
Descriptive statistics (mean, standard deviation, min, max, quartiles) were computed for all columns. This provided an overview of the range and central tendency of each operational setting and sensor measurement. For instance, `time_in_cycles` ranges from 1 to 362, indicating varying lifespans for the training engine units. Sensor readings exhibit diverse ranges and distributions, which will necessitate normalization or standardization before being fed into most machine learning models, especially neural networks, to ensure stable training.

**Constant Value Columns (Zero or Low Variance Features):**
The EDA also focused on identifying columns that do not change value across all records, as these columns provide no predictive information and can be safely removed. For the `train_FD001.txt` dataset, the following columns were found to have constant values:

*   `op_setting_3`: Constant at 100.0
*   `sensor_1`: Constant at 518.67
*   `sensor_5`: Constant at 14.62
*   `sensor_10`: Constant at 1.3
*   `sensor_16`: Constant at 0.03
*   `sensor_18`: Constant at 2388.0
*   `sensor_19`: Constant at 100.0

These constant columns will be dropped during the data cleaning phase of preprocessing. It is important to note that the constancy of these features might differ across other sub-datasets (FD002, FD003, FD004) due to different operational conditions or fault modes, so this check will be repeated for each subset.

**Next Steps in Preprocessing:**
Based on these EDA findings, the subsequent preprocessing steps will include:

1.  **Data Cleaning:** Removal of the identified constant value columns. Other cleaning steps, such as outlier detection and handling, will be considered based on further analysis and visualization of sensor data distributions and time-series plots for individual engines.
2.  **Feature Engineering - RUL Calculation for Training Data:** The `train_FD00x.txt` datasets do not explicitly contain the Remaining Useful Life (RUL) for each cycle. The RUL needs to be calculated. For each engine unit in the training set, the RUL at any given cycle is the total number of cycles for that engine minus the current cycle number. This will serve as the target variable for RUL prediction models.
3.  **Normalization/Standardization:** Sensor readings and operational settings often have different scales and units. To prevent features with larger magnitudes from dominating the learning process and to improve the convergence of gradient-based optimization algorithms, feature scaling techniques like Min-Max normalization (scaling to a [0, 1] range) or Z-score standardization (scaling to zero mean and unit variance) will be applied to the relevant input features.
4.  **Sequence Generation (for time-series models):** For models like LSTMs or CNNs that operate on sequences of data, the time-series data for each engine will need to be transformed into fixed-length sequences (windows) of sensor readings and corresponding RUL values. The choice of window size will be a critical hyperparameter.

This initial EDA has provided a solid foundation for the data preprocessing phase, ensuring that the data is appropriately cleaned, transformed, and structured for effective machine learning model development. The insights gained will guide the implementation of a robust data pipeline.



### 4.3. Final Preprocessing Steps: RUL Calculation, Normalization, and Sequence Generation

Building upon the insights from the Exploratory Data Analysis (EDA), the data preprocessing pipeline for the `train_FD001.txt` dataset was completed with the following key steps:

**1. Removal of Constant Columns:**
As identified during EDA, seven columns (`op_setting_3`, `sensor_1`, `sensor_5`, `sensor_10`, `sensor_16`, `sensor_18`, `sensor_19`) were found to have constant values across all records in the `train_FD001` subset. These columns provide no predictive information and were therefore dropped from the dataset. This reduces the dimensionality of the input features and streamlines the modeling process.

**2. Calculation of Remaining Useful Life (RUL):**
The primary objective of this project is to predict the Remaining Useful Life (RUL) of the turbofan engines. The provided training data (`train_FD00x.txt`) does not explicitly include an RUL column for each operational cycle. Therefore, the RUL was calculated for each engine unit. For a given engine unit, the RUL at any specific cycle is defined as the difference between the total number of cycles that engine operated before failure (its maximum cycle life in the training data) and the current cycle number. This piecewise linear degradation pattern for RUL is a common assumption for this dataset and serves as the target variable for the regression models.

**3. Feature Scaling (Min-Max Normalization):**
The operational settings and sensor measurements in the dataset have varying scales and units. To ensure that features with larger magnitudes do not disproportionately influence the model training process, and to aid in the convergence of gradient-based optimization algorithms (especially for neural networks), Min-Max normalization was applied. This technique scales all selected features (operational settings and non-constant sensor measurements) to a range between 0 and 1. The scaler object (`MinMaxScaler` from scikit-learn) was fitted only on the training data (`train_FD001`) and saved. This saved scaler will be used to transform the test data consistently during the evaluation phase, preventing data leakage from the test set into the training process.

**4. Sequence Generation for Time-Series Models:**
Deep learning models like LSTMs, which are planned for this project, require input data to be structured as sequences. The time-series data for each engine unit was transformed into overlapping sequences of a fixed length. A sequence length of 50 cycles was chosen as an initial hyperparameter. This means that each input sample for the LSTM model will consist of sensor readings and operational settings from 50 consecutive cycles. The target for each input sequence is the RUL value at the end of that 50-cycle window. This process involves sliding a window of 50 cycles over each engine's operational history, creating a new sequence at each step. This significantly augments the number of training samples.

The output of this preprocessing pipeline includes:
*   `X_train_fd001_sequences.npy`: A NumPy array containing the input sequences (number of sequences, 50 time steps, number of features per step).
*   `y_train_fd001_rul.npy`: A NumPy array containing the corresponding RUL target values for each sequence.
*   `min_max_scaler_fd001.save`: The saved Min-Max scaler object for transforming test data.

These preprocessed and structured data are now ready for training the selected machine learning models. The same preprocessing steps (using the scaler fitted on `train_FD001`) will be applied to the `test_FD001.txt` data and its corresponding `RUL_FD001.txt` for model evaluation.
