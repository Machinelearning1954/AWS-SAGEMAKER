#!/usr/bin/env python
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.optimizers import Adam
import keras_tuner as kt
import os

# Create a directory for saving models and plots if it doesn't exist
if not os.path.exists("/home/ubuntu/model_artifacts/tuning"):
    os.makedirs("/home/ubuntu/model_artifacts/tuning")

# Load preprocessed data
print("Loading preprocessed training data...")
X_train = np.load("/home/ubuntu/X_train_fd001_sequences.npy")
y_train = np.load("/home/ubuntu/y_train_fd001_rul.npy")

print(f"Shape of X_train: {X_train.shape}")
print(f"Shape of y_train: {y_train.shape}")

if X_train.shape[0] == 0:
    print("Error: No training sequences loaded. Exiting.")
    exit()

# Define the model-building function for Keras Tuner
def build_model(hp):
    model = Sequential()
    model.add(LSTM(
        units=hp.Int('units_lstm1', min_value=32, max_value=128, step=32),
        return_sequences=True,
        input_shape=(X_train.shape[1], X_train.shape[2])))
    model.add(Dropout(hp.Float('dropout_1', min_value=0.1, max_value=0.5, step=0.1)))
    
    model.add(LSTM(
        units=hp.Int('units_lstm2', min_value=32, max_value=128, step=32),
        return_sequences=False))
    model.add(Dropout(hp.Float('dropout_2', min_value=0.1, max_value=0.5, step=0.1)))
    
    model.add(Dense(units=1))
    
    model.compile(
        optimizer=Adam(hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])),
        loss='mean_squared_error',
        metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse')])
    return model

# Instantiate the tuner
print("Initializing Keras Tuner...")
tuner = kt.Hyperband(
    build_model,
    objective=kt.Objective("val_rmse", direction="min"),
    max_epochs=10, # Reduced for demonstration; in a real scenario, use more epochs
    factor=3,
    directory='/home/ubuntu/keras_tuner_dir',
    project_name='rul_prediction_tuning'
)

# Define early stopping callback for the tuning process
stop_early = EarlyStopping(monitor='val_loss', patience=5)

# Start the hyperparameter search
print("Starting hyperparameter search...")
tuner.search(X_train, y_train, epochs=20, validation_split=0.2, callbacks=[stop_early], batch_size=64)

# Get the optimal hyperparameters
best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]

print(f"""
The hyperparameter search is complete. The optimal number of units in the first LSTM layer is {best_hps.get('units_lstm1')}, 
the optimal dropout rate for the first LSTM layer is {best_hps.get('dropout_1')}, 
the optimal number of units in the second LSTM layer is {best_hps.get('units_lstm2')}, 
the optimal dropout rate for the second LSTM layer is {best_hps.get('dropout_2')}, 
and the optimal learning rate for the optimizer is {best_hps.get('learning_rate')}.
""")

# Build the model with the optimal hyperparameters and train it on the data
print("Building and training the best model...")
model = tuner.hypermodel.build(best_hps)
history = model.fit(X_train, y_train, epochs=50, validation_split=0.2, batch_size=64, 
                    callbacks=[EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True),
                               ModelCheckpoint("/home/ubuntu/model_artifacts/tuning/best_lstm_model_fd001.keras", save_best_only=True, monitor='val_loss')])

print("Best model training completed.")

# Save the best model
model.save("/home/ubuntu/model_artifacts/tuning/best_lstm_model_fd001_final.keras")
print("Best model saved to /home/ubuntu/model_artifacts/tuning/best_lstm_model_fd001_final.keras")

# Plot training history for the best model
print("Plotting training history for the best model...")
plt.figure(figsize=(12, 6))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Best Model Loss Over Epochs')
plt.ylabel('Mean Squared Error (Loss)')
plt.xlabel('Epoch')
plt.legend()
plt.savefig("/home/ubuntu/model_artifacts/tuning/best_model_loss_fd001.png")
print("Best model training loss plot saved.")

plt.figure(figsize=(12, 6))
plt.plot(history.history['rmse'], label='Training RMSE')
plt.plot(history.history['val_rmse'], label='Validation RMSE')
plt.title('Best Model RMSE Over Epochs')
plt.ylabel('Root Mean Squared Error')
plt.xlabel('Epoch')
plt.legend()
plt.savefig("/home/ubuntu/model_artifacts/tuning/best_model_rmse_fd001.png")
print("Best model training RMSE plot saved.")

print("Hyperparameter tuning script finished.")

# Further steps would involve evaluating this model on the test set (test_FD001.txt and RUL_FD001.txt)
# and then potentially repeating the process for FD002, FD003, FD004 datasets.

